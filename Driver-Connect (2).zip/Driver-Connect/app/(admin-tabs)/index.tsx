import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, useColorScheme, Platform } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Colors from '@/constants/colors';

export default function AdminDashboard() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? Colors.dark : Colors.light;

  const overviewStats = [
    { label: 'Total Drivers', value: '1,248', icon: 'people', color: Colors.accent, change: '+24' },
    { label: 'Total Owners', value: '356', icon: 'car', color: Colors.teal, change: '+8' },
    { label: t('revenue'), value: '\u20B94.2L', icon: 'trending-up', color: Colors.success, change: '+12%' },
    { label: 'Active Jobs', value: '89', icon: 'briefcase', color: '#8B5CF6', change: '+5' },
  ];

  const fraudAlerts = [
    { id: '1', type: 'GPS Jump', driver: 'Ankit Rao', severity: 'high', time: '2h ago' },
    { id: '2', type: 'Multiple Login', driver: 'Ravi Patil', severity: 'medium', time: '5h ago' },
    { id: '3', type: 'Fake Rating', driver: 'Sanjay M.', severity: 'low', time: '1d ago' },
  ];

  const kycPending = [
    { id: '1', name: 'Mahesh Kumar', type: 'Driver', submitted: '2h ago' },
    { id: '2', name: 'Prakash Joshi', type: 'Driver', submitted: '5h ago' },
    { id: '3', name: 'Arun Deshmukh', type: 'Owner', submitted: '1d ago' },
  ];

  const severityColors: Record<string, string> = {
    high: Colors.danger,
    medium: Colors.warning,
    low: Colors.teal,
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <View>
            <Text style={[styles.greeting, { color: theme.textSecondary }]}>Admin Panel</Text>
            <Text style={[styles.userName, { color: theme.text }]}>{user?.name || 'Admin'}</Text>
          </View>
          <View style={[styles.adminBadge, { backgroundColor: '#8B5CF6' + '15' }]}>
            <Ionicons name="shield-checkmark" size={16} color="#8B5CF6" />
            <Text style={{ fontSize: 12, fontFamily: 'Poppins_600SemiBold', color: '#8B5CF6' }}>Admin</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          {overviewStats.map((stat, index) => (
            <View key={index} style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <View style={styles.statTop}>
                <View style={[styles.statIcon, { backgroundColor: stat.color + '15' }]}>
                  <Ionicons name={stat.icon as any} size={18} color={stat.color} />
                </View>
                <View style={[styles.changeBadge, { backgroundColor: Colors.success + '15' }]}>
                  <Text style={{ fontSize: 10, fontFamily: 'Poppins_600SemiBold', color: Colors.success }}>{stat.change}</Text>
                </View>
              </View>
              <Text style={[styles.statValue, { color: theme.text }]}>{stat.value}</Text>
              <Text style={[styles.statLabel, { color: theme.textSecondary }]}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.revenueCard}>
          <LinearGradient colors={['#8B5CF6', '#A78BFA']} style={styles.revenueGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <View style={styles.revenueTop}>
              <Text style={styles.revenueLabel}>{t('thisMonth')} {t('revenue')}</Text>
              <Ionicons name="trending-up" size={20} color="rgba(255,255,255,0.8)" />
            </View>
            <Text style={styles.revenueAmount}>{'\u20B9'}4,21,500</Text>
            <View style={styles.revenueBreakdown}>
              <View style={styles.revenueItem}>
                <Text style={styles.revenueItemLabel}>Commission</Text>
                <Text style={styles.revenueItemValue}>{'\u20B9'}3,15,000</Text>
              </View>
              <View style={styles.revenueItem}>
                <Text style={styles.revenueItemLabel}>Boost Ads</Text>
                <Text style={styles.revenueItemValue}>{'\u20B9'}85,000</Text>
              </View>
              <View style={styles.revenueItem}>
                <Text style={styles.revenueItemLabel}>Subscriptions</Text>
                <Text style={styles.revenueItemValue}>{'\u20B9'}21,500</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleRow}>
              <Ionicons name="warning" size={18} color={Colors.danger} />
              <Text style={[styles.sectionTitle, { color: theme.text }]}>{t('fraudAlerts')}</Text>
            </View>
            <View style={[styles.countBadge, { backgroundColor: Colors.danger + '15' }]}>
              <Text style={{ fontSize: 12, fontFamily: 'Poppins_600SemiBold', color: Colors.danger }}>{fraudAlerts.length}</Text>
            </View>
          </View>
          {fraudAlerts.map((alert) => (
            <View key={alert.id} style={[styles.alertCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <View style={[styles.severityBar, { backgroundColor: severityColors[alert.severity] }]} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.alertType, { color: theme.text }]}>{alert.type}</Text>
                <Text style={[styles.alertDriver, { color: theme.textSecondary }]}>{alert.driver}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <View style={[styles.severityBadge, { backgroundColor: severityColors[alert.severity] + '15' }]}>
                  <Text style={{ fontSize: 10, fontFamily: 'Poppins_600SemiBold', color: severityColors[alert.severity], textTransform: 'uppercase' as const }}>{alert.severity}</Text>
                </View>
                <Text style={[styles.alertTime, { color: theme.textTertiary }]}>{alert.time}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleRow}>
              <Ionicons name="document-text" size={18} color={Colors.warning} />
              <Text style={[styles.sectionTitle, { color: theme.text }]}>KYC {t('pending')}</Text>
            </View>
            <View style={[styles.countBadge, { backgroundColor: Colors.warning + '15' }]}>
              <Text style={{ fontSize: 12, fontFamily: 'Poppins_600SemiBold', color: Colors.warning }}>{kycPending.length}</Text>
            </View>
          </View>
          {kycPending.map((kyc) => (
            <View key={kyc.id} style={[styles.kycCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <LinearGradient colors={[Colors.primary, Colors.primaryLight]} style={styles.kycAvatar}>
                <Text style={styles.kycAvatarText}>{kyc.name.charAt(0)}</Text>
              </LinearGradient>
              <View style={{ flex: 1 }}>
                <Text style={[styles.kycName, { color: theme.text }]}>{kyc.name}</Text>
                <Text style={[styles.kycMeta, { color: theme.textSecondary }]}>{kyc.type} - {kyc.submitted}</Text>
              </View>
              <View style={styles.kycActions}>
                <Pressable style={[styles.kycReject, { borderColor: Colors.danger }]}>
                  <Ionicons name="close" size={16} color={Colors.danger} />
                </Pressable>
                <Pressable>
                  <LinearGradient colors={[Colors.success, '#16A34A']} style={styles.kycApprove}>
                    <Ionicons name="checkmark" size={16} color="#FFF" />
                  </LinearGradient>
                </Pressable>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting: { fontSize: 13, fontFamily: 'Poppins_400Regular' },
  userName: { fontSize: 22, fontFamily: 'Poppins_700Bold' },
  adminBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  statCard: { width: '48%' as any, flexGrow: 1, borderRadius: 14, padding: 14, borderWidth: 1 },
  statTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  statIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  changeBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  statValue: { fontSize: 22, fontFamily: 'Poppins_700Bold' },
  statLabel: { fontSize: 11, fontFamily: 'Poppins_400Regular', marginTop: 2 },
  revenueCard: { borderRadius: 20, overflow: 'hidden', marginBottom: 20 },
  revenueGradient: { padding: 20 },
  revenueTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  revenueLabel: { fontSize: 14, fontFamily: 'Poppins_400Regular', color: 'rgba(255,255,255,0.8)' },
  revenueAmount: { fontSize: 36, fontFamily: 'Poppins_700Bold', color: '#FFF', marginTop: 4, marginBottom: 16 },
  revenueBreakdown: { flexDirection: 'row', justifyContent: 'space-between' },
  revenueItem: { alignItems: 'center' },
  revenueItemLabel: { fontSize: 11, fontFamily: 'Poppins_400Regular', color: 'rgba(255,255,255,0.6)' },
  revenueItemValue: { fontSize: 14, fontFamily: 'Poppins_600SemiBold', color: '#FFF', marginTop: 2 },
  section: { marginBottom: 20 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  sectionTitle: { fontSize: 18, fontFamily: 'Poppins_600SemiBold' },
  countBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  alertCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, borderWidth: 1, marginBottom: 8, gap: 12 },
  severityBar: { width: 3, height: 30, borderRadius: 2 },
  alertType: { fontSize: 14, fontFamily: 'Poppins_600SemiBold' },
  alertDriver: { fontSize: 12, fontFamily: 'Poppins_400Regular', marginTop: 2 },
  severityBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  alertTime: { fontSize: 11, fontFamily: 'Poppins_400Regular', marginTop: 4 },
  kycCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, borderWidth: 1, marginBottom: 8, gap: 12 },
  kycAvatar: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  kycAvatarText: { fontSize: 16, fontFamily: 'Poppins_700Bold', color: '#FFF' },
  kycName: { fontSize: 14, fontFamily: 'Poppins_600SemiBold' },
  kycMeta: { fontSize: 12, fontFamily: 'Poppins_400Regular', marginTop: 2 },
  kycActions: { flexDirection: 'row', gap: 6 },
  kycReject: { width: 32, height: 32, borderRadius: 8, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  kycApprove: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
});

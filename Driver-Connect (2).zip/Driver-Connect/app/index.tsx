import React, { useEffect } from 'react';
import { View, Text, StyleSheet, useColorScheme, Platform, Image } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { useSharedValue, useAnimatedStyle, withTiming, withDelay, withSequence } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Colors from '@/constants/colors';

const logoImage = require('@/assets/images/logo.png');

export default function SplashScreen() {
  const { isLoggedIn, isLoading, user } = useAuth();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();

  const titleOpacity = useSharedValue(0);
  const titleTranslateY = useSharedValue(30);
  const taglineOpacity = useSharedValue(0);
  const taglineTranslateY = useSharedValue(20);

  useEffect(() => {
    titleOpacity.value = withTiming(1, { duration: 800 });
    titleTranslateY.value = withTiming(0, { duration: 800 });
    taglineOpacity.value = withDelay(400, withTiming(1, { duration: 600 }));
    taglineTranslateY.value = withDelay(400, withTiming(0, { duration: 600 }));

    const timer = setTimeout(() => {
      if (isLoading) return;
      if (isLoggedIn && user) {
        const route = user.role === 'driver' ? '/(driver-tabs)' :
                      user.role === 'owner' ? '/(owner-tabs)' : '/(admin-tabs)';
        router.replace(route as any);
      } else {
        router.replace('/role-select' as any);
      }
    }, 2200);

    return () => clearTimeout(timer);
  }, [isLoading, isLoggedIn, user]);

  const titleStyle = useAnimatedStyle(() => ({
    opacity: titleOpacity.value,
    transform: [{ translateY: titleTranslateY.value }],
  }));

  const taglineStyle = useAnimatedStyle(() => ({
    opacity: taglineOpacity.value,
    transform: [{ translateY: taglineTranslateY.value }],
  }));

  return (
    <LinearGradient
      colors={['#0F1B2D', '#1B2838', '#0F1B2D']}
      style={styles.container}
    >
      <View style={[styles.content, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0) }]}>
        <Animated.View style={titleStyle}>
          <Image source={logoImage} style={styles.logo} resizeMode="contain" />
        </Animated.View>
        <Animated.View style={[taglineStyle, styles.loaderContainer]}>
          <View style={styles.loader}>
            <LinearGradient
              colors={[Colors.accent, Colors.accentLight]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.loaderBar}
            />
          </View>
        </Animated.View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  logo: {
    width: 280,
    height: 200,
  },
  loaderContainer: {
    marginTop: 40,
  },
  loader: {
    width: 120,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  loaderBar: {
    width: '60%',
    height: '100%',
    borderRadius: 2,
  },
});

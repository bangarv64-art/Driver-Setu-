import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, useColorScheme, Platform, ScrollView, Alert, Switch } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Colors from '@/constants/colors';

export default function DriverDashboard() {
  const { user, updateProfile } = useAuth();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? Colors.dark : Colors.light;

  const [isOnline, setIsOnline] = useState(user?.isOnline ?? false);
  const sosScale = useSharedValue(1);

  const sosAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: sosScale.value }],
  }));

  async function toggleOnline() {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const newStatus = !isOnline;
    setIsOnline(newStatus);
    await updateProfile({ isOnline: newStatus });
  }

  function handleSOS() {
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    sosScale.value = withSpring(0.9, {}, () => {
      sosScale.value = withSpring(1);
    });
    Alert.alert(t('sosAlert'), t('sosDesc'));
  }

  const stats = [
    { label: t('rating'), value: user?.rating?.toFixed(1) || '4.7', icon: 'star', color: Colors.gold },
    { label: t('trustScore'), value: (user?.trustScore || 85) + '%', icon: 'shield-checkmark', color: Colors.teal },
    { label: t('trips'), value: user?.totalTrips?.toString() || '1,247', icon: 'car', color: Colors.accent },
    { label: t('completionRate'), value: (user?.completionRate || 94) + '%', icon: 'checkmark-circle', color: Colors.success },
  ];

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16),
            paddingBottom: 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <View>
            <Text style={[styles.greeting, { color: theme.textSecondary }]}>
              {t('dashboard')}
            </Text>
            <Text style={[styles.userName, { color: theme.text }]}>
              {user?.name || 'Driver'}
            </Text>
          </View>
          <View style={styles.topBarActions}>
            <Pressable
              onPress={() => router.push('/language' as any)}
              style={[styles.iconBtn, { backgroundColor: theme.surface }]}
            >
              <Ionicons name="language" size={20} color={theme.text} />
            </Pressable>
          </View>
        </View>

        <View style={[styles.statusCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <View style={styles.statusRow}>
            <View style={styles.statusLeft}>
              <View style={[styles.statusDot, { backgroundColor: isOnline ? Colors.success : theme.textTertiary }]} />
              <Text style={[styles.statusText, { color: theme.text }]}>
                {isOnline ? t('online') : t('offline')}
              </Text>
            </View>
            <Switch
              value={isOnline}
              onValueChange={toggleOnline}
              trackColor={{ false: theme.border, true: Colors.success + '50' }}
              thumbColor={isOnline ? Colors.success : theme.textTertiary}
            />
          </View>
          {user?.kycStatus && (
            <View style={[styles.kycBadge, {
              backgroundColor: user.kycStatus === 'approved' ? Colors.success + '15' :
                user.kycStatus === 'rejected' ? Colors.danger + '15' : Colors.warning + '15',
            }]}>
              <Ionicons
                name={user.kycStatus === 'approved' ? 'checkmark-circle' : user.kycStatus === 'rejected' ? 'close-circle' : 'time'}
                size={16}
                color={user.kycStatus === 'approved' ? Colors.success : user.kycStatus === 'rejected' ? Colors.danger : Colors.warning}
              />
              <Text style={{
                fontSize: 12,
                fontFamily: 'Poppins_500Medium',
                color: user.kycStatus === 'approved' ? Colors.success : user.kycStatus === 'rejected' ? Colors.danger : Colors.warning,
              }}>
                {t(user.kycStatus === 'approved' ? 'kycApproved' : user.kycStatus === 'rejected' ? 'kycRejected' : 'kycPending')}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.walletCard}>
          <LinearGradient
            colors={['#1B2838', '#2A3F56']}
            style={styles.walletGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.walletTop}>
              <View>
                <Text style={styles.walletLabel}>{t('balance')}</Text>
                <Text style={styles.walletAmount}>
                  {'\u20B9'}{(user?.walletBalance || 12500).toLocaleString()}
                </Text>
              </View>
              <Pressable style={styles.withdrawBtn} onPress={() => {
                if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                Alert.alert(t('withdrawRequest'), 'Request sent to admin for approval');
              }}>
                <Text style={styles.withdrawText}>{t('withdraw')}</Text>
              </Pressable>
            </View>
            <View style={styles.walletDivider} />
            <View style={styles.walletBottom}>
              <View style={styles.walletStat}>
                <Text style={styles.walletStatLabel}>{t('today')}</Text>
                <Text style={styles.walletStatValue}>{'\u20B9'}850</Text>
              </View>
              <View style={styles.walletStat}>
                <Text style={styles.walletStatLabel}>{t('thisWeek')}</Text>
                <Text style={styles.walletStatValue}>{'\u20B9'}4,200</Text>
              </View>
              <View style={styles.walletStat}>
                <Text style={styles.walletStatLabel}>{t('thisMonth')}</Text>
                <Text style={styles.walletStatValue}>{'\u20B9'}12,500</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        <View style={styles.statsGrid}>
          {stats.map((stat, index) => (
            <View key={index} style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <Ionicons name={stat.icon as any} size={22} color={stat.color} />
              <Text style={[styles.statValue, { color: theme.text }]}>{stat.value}</Text>
              <Text style={[styles.statLabel, { color: theme.textSecondary }]}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <Animated.View style={sosAnimStyle}>
          <Pressable onPress={handleSOS} style={styles.sosButton}>
            <LinearGradient
              colors={[Colors.danger, '#DC2626']}
              style={styles.sosGradient}
            >
              <Ionicons name="warning" size={28} color="#FFF" />
              <Text style={styles.sosText}>{t('sos')}</Text>
            </LinearGradient>
          </Pressable>
        </Animated.View>

        <View style={styles.quickActions}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>{t('jobRequests')}</Text>
          {[
            { title: 'Mumbai - Pune Transfer', owner: 'Suresh Patil', salary: '2,500', time: '2h ago', distance: '148 km' },
            { title: 'Local City Driving', owner: 'Amit Shah', salary: '1,200', time: '4h ago', distance: '25 km' },
          ].map((job, index) => (
            <View key={index} style={[styles.jobCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <View style={styles.jobCardTop}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.jobTitle, { color: theme.text }]}>{job.title}</Text>
                  <Text style={[styles.jobOwner, { color: theme.textSecondary }]}>{job.owner}</Text>
                </View>
                <Text style={[styles.jobSalary, { color: Colors.accent }]}>{'\u20B9'}{job.salary}</Text>
              </View>
              <View style={styles.jobMeta}>
                <View style={styles.jobMetaItem}>
                  <Ionicons name="location" size={14} color={theme.textTertiary} />
                  <Text style={[styles.jobMetaText, { color: theme.textTertiary }]}>{job.distance}</Text>
                </View>
                <View style={styles.jobMetaItem}>
                  <Ionicons name="time" size={14} color={theme.textTertiary} />
                  <Text style={[styles.jobMetaText, { color: theme.textTertiary }]}>{job.time}</Text>
                </View>
              </View>
              <View style={styles.jobActions}>
                <Pressable
                  style={[styles.rejectBtn, { borderColor: Colors.danger }]}
                  onPress={() => {
                    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  }}
                >
                  <Ionicons name="close" size={18} color={Colors.danger} />
                </Pressable>
                <Pressable
                  style={styles.acceptBtn}
                  onPress={() => {
                    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                    Alert.alert('Job Accepted', 'You have accepted this job');
                  }}
                >
                  <LinearGradient
                    colors={[Colors.success, '#16A34A']}
                    style={styles.acceptBtnGradient}
                  >
                    <Ionicons name="checkmark" size={18} color="#FFF" />
                    <Text style={styles.acceptText}>{t('accept')}</Text>
                  </LinearGradient>
                </Pressable>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting: { fontSize: 13, fontFamily: 'Poppins_400Regular' },
  userName: { fontSize: 22, fontFamily: 'Poppins_700Bold' },
  topBarActions: { flexDirection: 'row', gap: 8 },
  iconBtn: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  statusCard: { borderRadius: 16, padding: 16, borderWidth: 1, marginBottom: 16, gap: 12 },
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statusLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  statusText: { fontSize: 16, fontFamily: 'Poppins_600SemiBold' },
  kycBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 6, paddingHorizontal: 12, borderRadius: 8, alignSelf: 'flex-start' },
  walletCard: { borderRadius: 20, overflow: 'hidden', marginBottom: 16 },
  walletGradient: { padding: 20 },
  walletTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  walletLabel: { fontSize: 13, fontFamily: 'Poppins_400Regular', color: 'rgba(255,255,255,0.7)' },
  walletAmount: { fontSize: 32, fontFamily: 'Poppins_700Bold', color: '#FFF', marginTop: 4 },
  withdrawBtn: { backgroundColor: Colors.accent, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10 },
  withdrawText: { fontSize: 13, fontFamily: 'Poppins_600SemiBold', color: '#FFF' },
  walletDivider: { height: 1, backgroundColor: 'rgba(255,255,255,0.1)', marginVertical: 16 },
  walletBottom: { flexDirection: 'row', justifyContent: 'space-between' },
  walletStat: { alignItems: 'center' },
  walletStatLabel: { fontSize: 11, fontFamily: 'Poppins_400Regular', color: 'rgba(255,255,255,0.5)' },
  walletStatValue: { fontSize: 16, fontFamily: 'Poppins_600SemiBold', color: '#FFF', marginTop: 2 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  statCard: { width: '48%' as any, flexGrow: 1, borderRadius: 14, padding: 14, borderWidth: 1, gap: 6 },
  statValue: { fontSize: 20, fontFamily: 'Poppins_700Bold' },
  statLabel: { fontSize: 11, fontFamily: 'Poppins_400Regular' },
  sosButton: { borderRadius: 16, overflow: 'hidden', marginBottom: 20 },
  sosGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 18, gap: 10 },
  sosText: { fontSize: 20, fontFamily: 'Poppins_700Bold', color: '#FFF', letterSpacing: 2 },
  quickActions: { marginBottom: 20 },
  sectionTitle: { fontSize: 18, fontFamily: 'Poppins_600SemiBold', marginBottom: 12 },
  jobCard: { borderRadius: 14, padding: 16, borderWidth: 1, marginBottom: 12 },
  jobCardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  jobTitle: { fontSize: 15, fontFamily: 'Poppins_600SemiBold' },
  jobOwner: { fontSize: 13, fontFamily: 'Poppins_400Regular', marginTop: 2 },
  jobSalary: { fontSize: 18, fontFamily: 'Poppins_700Bold' },
  jobMeta: { flexDirection: 'row', gap: 16, marginTop: 10 },
  jobMetaItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  jobMetaText: { fontSize: 12, fontFamily: 'Poppins_400Regular' },
  jobActions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  rejectBtn: { width: 42, height: 42, borderRadius: 12, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  acceptBtn: { flex: 1, borderRadius: 12, overflow: 'hidden' },
  acceptBtnGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: 42, gap: 6 },
  acceptText: { fontSize: 14, fontFamily: 'Poppins_600SemiBold', color: '#FFF' },
});

import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, useColorScheme, Platform, Alert } from 'react-native';
import { router } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Colors from '@/constants/colors';

export default function DriverProfileScreen() {
  const { user, updateProfile, logout } = useAuth();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? Colors.dark : Colors.light;

  async function handleImageUpload(type: 'license' | 'aadhaar') {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.8,
    });
    if (!result.canceled) {
      if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      if (type === 'license') {
        await updateProfile({ licenseUploaded: true });
      } else {
        await updateProfile({ aadhaarUploaded: true });
      }
      Alert.alert('Uploaded', `${type === 'license' ? 'Driving License' : 'Aadhaar Card'} uploaded successfully`);
    }
  }

  async function handleLogout() {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(t('logout'), 'Are you sure?', [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('confirm'),
        style: 'destructive',
        onPress: async () => {
          await logout();
          router.replace('/role-select' as any);
        },
      },
    ]);
  }

  const menuItems = [
    {
      icon: 'card-outline' as const,
      label: t('uploadLicense'),
      subtitle: user?.licenseUploaded ? 'Uploaded' : 'Required',
      status: user?.licenseUploaded ? 'done' : 'pending',
      onPress: () => handleImageUpload('license'),
    },
    {
      icon: 'id-card-outline' as const,
      label: t('uploadAadhaar'),
      subtitle: user?.aadhaarUploaded ? 'Uploaded' : 'Required',
      status: user?.aadhaarUploaded ? 'done' : 'pending',
      onPress: () => handleImageUpload('aadhaar'),
    },
    {
      icon: 'language-outline' as const,
      label: t('language'),
      subtitle: '',
      onPress: () => router.push('/language' as any),
    },
  ];

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.headerTitle, { color: theme.text }]}>{t('profile')}</Text>

        <View style={[styles.profileCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <View style={styles.avatarContainer}>
            <LinearGradient colors={[Colors.accent, Colors.accentLight]} style={styles.avatar}>
              <Text style={styles.avatarText}>
                {(user?.name || 'D').charAt(0).toUpperCase()}
              </Text>
            </LinearGradient>
            {user?.isVerified && (
              <View style={styles.verifiedBadge}>
                <Ionicons name="checkmark-circle" size={22} color={Colors.teal} />
              </View>
            )}
          </View>
          <Text style={[styles.profileName, { color: theme.text }]}>{user?.name || 'Driver'}</Text>
          <Text style={[styles.profilePhone, { color: theme.textSecondary }]}>+91 {user?.phone}</Text>

          <View style={styles.profileStats}>
            <View style={styles.profileStat}>
              <Text style={[styles.profileStatValue, { color: Colors.gold }]}>
                <Ionicons name="star" size={14} color={Colors.gold} /> {user?.rating?.toFixed(1) || '4.7'}
              </Text>
              <Text style={[styles.profileStatLabel, { color: theme.textSecondary }]}>{t('rating')}</Text>
            </View>
            <View style={[styles.profileStatDivider, { backgroundColor: theme.border }]} />
            <View style={styles.profileStat}>
              <Text style={[styles.profileStatValue, { color: Colors.teal }]}>{user?.trustScore || 85}%</Text>
              <Text style={[styles.profileStatLabel, { color: theme.textSecondary }]}>{t('trustScore')}</Text>
            </View>
            <View style={[styles.profileStatDivider, { backgroundColor: theme.border }]} />
            <View style={styles.profileStat}>
              <Text style={[styles.profileStatValue, { color: Colors.accent }]}>{user?.experience || 5} {t('years')}</Text>
              <Text style={[styles.profileStatLabel, { color: theme.textSecondary }]}>{t('experience')}</Text>
            </View>
          </View>
        </View>

        <View style={[styles.kycSection, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <View style={styles.kycHeader}>
            <Ionicons name="shield-checkmark" size={20} color={Colors.teal} />
            <Text style={[styles.kycTitle, { color: theme.text }]}>{t('kyc')}</Text>
          </View>
          <View style={[styles.kycStatus, {
            backgroundColor: user?.kycStatus === 'approved' ? Colors.success + '10' :
              user?.kycStatus === 'rejected' ? Colors.danger + '10' : Colors.warning + '10',
          }]}>
            <Ionicons
              name={user?.kycStatus === 'approved' ? 'checkmark-circle' : user?.kycStatus === 'rejected' ? 'close-circle' : 'time'}
              size={18}
              color={user?.kycStatus === 'approved' ? Colors.success : user?.kycStatus === 'rejected' ? Colors.danger : Colors.warning}
            />
            <Text style={{
              fontSize: 14,
              fontFamily: 'Poppins_500Medium',
              color: user?.kycStatus === 'approved' ? Colors.success : user?.kycStatus === 'rejected' ? Colors.danger : Colors.warning,
            }}>
              {t(user?.kycStatus === 'approved' ? 'kycApproved' : user?.kycStatus === 'rejected' ? 'kycRejected' : 'kycPending')}
            </Text>
          </View>
        </View>

        <View style={[styles.menuSection, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          {menuItems.map((item, index) => (
            <Pressable
              key={index}
              onPress={item.onPress}
              style={({ pressed }) => [
                styles.menuItem,
                index < menuItems.length - 1 && { borderBottomWidth: 0.5, borderBottomColor: theme.border },
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Ionicons name={item.icon} size={22} color={theme.textSecondary} />
              <View style={styles.menuItemText}>
                <Text style={[styles.menuItemLabel, { color: theme.text }]}>{item.label}</Text>
                {item.subtitle ? (
                  <Text style={[styles.menuItemSubtitle, {
                    color: item.status === 'done' ? Colors.success : Colors.warning
                  }]}>{item.subtitle}</Text>
                ) : null}
              </View>
              <Ionicons name="chevron-forward" size={18} color={theme.textTertiary} />
            </Pressable>
          ))}
        </View>

        <Pressable onPress={handleLogout} style={[styles.logoutBtn, { borderColor: Colors.danger }]}>
          <Ionicons name="log-out-outline" size={20} color={Colors.danger} />
          <Text style={[styles.logoutText, { color: Colors.danger }]}>{t('logout')}</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  headerTitle: { fontSize: 24, fontFamily: 'Poppins_700Bold', marginBottom: 20 },
  profileCard: { borderRadius: 20, padding: 24, borderWidth: 1, alignItems: 'center', marginBottom: 16 },
  avatarContainer: { position: 'relative', marginBottom: 12 },
  avatar: { width: 80, height: 80, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 32, fontFamily: 'Poppins_700Bold', color: '#FFF' },
  verifiedBadge: { position: 'absolute', bottom: -4, right: -4, backgroundColor: '#FFF', borderRadius: 12 },
  profileName: { fontSize: 20, fontFamily: 'Poppins_700Bold' },
  profilePhone: { fontSize: 14, fontFamily: 'Poppins_400Regular', marginTop: 2 },
  profileStats: { flexDirection: 'row', marginTop: 20, alignItems: 'center' },
  profileStat: { flex: 1, alignItems: 'center' },
  profileStatValue: { fontSize: 16, fontFamily: 'Poppins_600SemiBold' },
  profileStatLabel: { fontSize: 11, fontFamily: 'Poppins_400Regular', marginTop: 2 },
  profileStatDivider: { width: 1, height: 30 },
  kycSection: { borderRadius: 16, padding: 16, borderWidth: 1, marginBottom: 16, gap: 12 },
  kycHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  kycTitle: { fontSize: 16, fontFamily: 'Poppins_600SemiBold' },
  kycStatus: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderRadius: 10 },
  menuSection: { borderRadius: 16, borderWidth: 1, overflow: 'hidden', marginBottom: 20 },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  menuItemText: { flex: 1 },
  menuItemLabel: { fontSize: 14, fontFamily: 'Poppins_500Medium' },
  menuItemSubtitle: { fontSize: 12, fontFamily: 'Poppins_400Regular', marginTop: 1 },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 16, borderRadius: 14, borderWidth: 1.5 },
  logoutText: { fontSize: 15, fontFamily: 'Poppins_600SemiBold' },
});
